#function with docstring
def func1(name1):
    "iam anitha good evening"
print(func1.__doc__)
