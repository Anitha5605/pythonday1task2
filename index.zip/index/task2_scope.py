#lambda is a annomous function which means a function without name is called ananomours
#in python lambda function is used for single statement it accepts multiple arguements but only one expression it is defined with lambda keyword instead of def keyword
d=lambda n=n*n
print(d(2))
a=10
def func():
    print(a)
func()
print(a)#global scope

def func1()
a=10
print(a)
func1()
print(a)#local scope 
