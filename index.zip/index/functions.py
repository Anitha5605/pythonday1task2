#what is function?
#function is a block of code it perform particular task when something calls it
#it is created by def keyword folowed by ()
#def func_name():
#    print("hello")        
#func_name()
#types of arguements
#1)positional arguements /required arguements
#the positional arguements means passing arguements in the same order of function's parameter (in this the order of parameter and arguements must be same in the function)
#example:
#def func(name,age):
  #  print(name)
  #  print(age)
#func("anitha",50)
#keyword arguements are defined as it allows user to pass values with parameters in the function so that order does not matter
#def func(name,age):
  #  print(name)
   # print(age)
#func(name="anitha",age=20)
#default arguements  it provides default value in the function definition and the default value always specified in the last
#def func(name,branch="cse"):
     #    print(name)
       #  print(branch)
#func("anitha")
variable lenght arguements it is divided into two types :
    1)
   

    
