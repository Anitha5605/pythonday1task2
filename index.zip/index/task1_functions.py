#Output Example:
#Factorial of 5 is: 120
#Args: (1, 2, 3), Kwargs: {'x': 10, 'y': 20}
a=int(input("enter the value"))
pro=1
for i in range(1,a+1):
    pro=pro*i
print(pro)
